#include <iostream>

using namespace std;


void main(void)
{
	cout<<"hello world\n";
	system("pause");
}
