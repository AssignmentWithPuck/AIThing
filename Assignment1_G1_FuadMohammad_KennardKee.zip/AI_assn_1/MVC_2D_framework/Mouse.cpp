#ifndef __MOUSE_H__
#include "Mouse.h"
#endif

CMouse::CMouse(void)
{
}

CMouse::~CMouse(void)
{
}
